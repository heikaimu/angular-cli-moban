import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-echart',
  templateUrl: './c-echart.component.html',
  styleUrls: ['./c-echart.component.scss']
})
export class CEchartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
