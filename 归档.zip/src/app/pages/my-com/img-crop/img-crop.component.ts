import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-img-crop',
  templateUrl: './img-crop.component.html',
  styleUrls: ['./img-crop.component.scss']
})
export class ImgCropComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
