import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-editor',
  templateUrl: './c-editor.component.html',
  styleUrls: ['./c-editor.component.scss']
})
export class CEditorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
