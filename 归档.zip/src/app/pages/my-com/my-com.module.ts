import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { myComRoutes } from './my-com.routes';

import { CEchartComponent } from './c-echart/c-echart.component';
import { CEditorComponent } from './c-editor/c-editor.component';
import { CTableComponent } from './c-table/c-table.component';
import { ImgCropComponent } from './img-crop/img-crop.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    myComRoutes
  ],
  declarations: [
    CEchartComponent,
    CEditorComponent,
    CTableComponent,
    ImgCropComponent
  ],
  exports: []
})

export class MyComModule {}
