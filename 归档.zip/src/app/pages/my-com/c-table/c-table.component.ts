import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-table',
  templateUrl: './c-table.component.html',
  styleUrls: ['./c-table.component.scss']
})
export class CTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
