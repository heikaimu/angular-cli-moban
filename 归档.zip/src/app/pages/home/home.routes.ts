import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';

const ROUTES: Routes = [
  {
    path: '',
    component: HomeComponent,
    // children: [
    //   {
    //     path: '',
    //     loadChildren: '../my-com/my-com.module#MyComModule'
    //   }
    // ]
  }
];

export const homeRoutes = RouterModule.forChild(ROUTES);
