import { Routes, RouterModule } from '@angular/router';

const ROUTES: Routes = [
  {
    path: 'home',
    loadChildren: './pages/home/home.module#HomeModule'
  }
];

export const appRoutes = RouterModule.forRoot(ROUTES, { useHash: true });
